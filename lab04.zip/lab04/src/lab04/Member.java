package lab04;

import java.util.ArrayList;

public class Member {
	    private String name;
	    private ArrayList<Book> borrowedBooks;

	    public Member(String name) {
	        this.name = name;
	        this.borrowedBooks = new ArrayList<>();
	    }

	    public void borrowBook(Library library, String title) {
	        Book book = library.searchBook(title);
	        if (book != null && book.borrowBook()) {
	            borrowedBooks.add(book);
	            System.out.println(name + " borrowed " + title);
	        } else {
	            System.out.println(title + " is not available.");
	        }
	    }

	    public void returnBook(Library library, String title) {
	        for (Book book : borrowedBooks) {
	            if (book.getTitle().equalsIgnoreCase(title)) {
	                book.returnBook();
	                borrowedBooks.remove(book);
	                System.out.println(name + " returned " + title);
	                return;
	            }
	        }
	        System.out.println(name + " does not have " + title);
	    }

}
