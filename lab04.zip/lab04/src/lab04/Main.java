package lab04;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Library library = new Library();
        Book book1 = new Book("1989", "Ho", true);
        Book book2 = new Book("hi", "me", true);
        Book book3 = new Book("Me", "hi", true);

        library.addBook(book1);
        library.addBook(book2);
        library.addBook(book3);

        Member member1 = new Member("Alice");
        member1.borrowBook(library, "1989");
       

        library.displayBooks();
        member1.borrowBook(library, "1989");
        library.displayBooks();
        library.removeBook("1989");
        library.displayBooks();
        library.searchBook("1989");
    }
}