package lab04;

import java.util.ArrayList;

public class Book {
    private String title;
    private String author;
    boolean isAvalible;

    public Book() {
        title = "";
        author = "";
        isAvalible = true;
    }

    public Book(String title, String author, boolean isAvalible) {
        this.title = title;
        this.author = author;
        this.isAvalible = isAvalible;
    }

    public String getTitle() {
        return title;
    }

    public boolean borrowBook() {
        if (isAvalible) {
            isAvalible = false;
            return true;
        }
        return false;
    }

    public void returnBook() {
        isAvalible = true;
    }

    @Override
    public String toString() {
        return "Title: " + this.title + " Author: " + this.author + " Is Available? " + this.isAvalible;
    }
}

